Description
�����������

SLARToolkit is a flexible Augmented Reality framework for Silverlight with the aim to make real time Augmented Reality applications with Silverlight as easy and fast as possible. It can be used with the Silverlight's Webcam API or with any other CaptureSource or WriteableBitmap. SLARTookit is based on the established NyARToolkit and ARToolkit. 



See http://slartoolkit.codeplex.com


Project structure
�����������������

Solution: The Visual Studio solutions for the library itself and the samples.
Source:   The Visual Studio projects for the samples and the SLARToolkit library.


License
�������

SLARToolkit uses a dual license model and could be used for open or closed source applications under certain conditions. See the License.txt file for details.