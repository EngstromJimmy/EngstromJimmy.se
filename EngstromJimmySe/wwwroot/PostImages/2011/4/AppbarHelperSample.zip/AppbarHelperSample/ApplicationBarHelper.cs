﻿using System;
using System.Linq;
using Microsoft.Phone.Shell;

namespace Helpers
{
    public class ApplicationBarHelper
    {
        public static string GetTranslation(object objectWithTranslations,string name)
        {
            
            var translationproperty = objectWithTranslations.GetType().GetProperties().SingleOrDefault(p => p.Name == name);
            if (translationproperty == null)
                return name;
            try
            {
                return translationproperty.GetValue(objectWithTranslations, null).ToString();
            }
            catch
            { }
            return name;        
        }

        public static void LocalizeAppBar(object objectWithTranslations, IApplicationBar applicationBar) 
        {
            if (applicationBar!=null) 
            {
                foreach (object obj in applicationBar.Buttons) 
                { 
                    IApplicationBarIconButton button = obj as IApplicationBarIconButton; 
                    if (null != button) 
                    {
                        button.Text = GetTranslation(objectWithTranslations,button.Text);
                    } 
                }
                foreach (object obj in applicationBar.MenuItems) 
                { 
                    IApplicationBarMenuItem menuItem = obj as IApplicationBarMenuItem; 
                    if (null != menuItem) 
                    {
                        menuItem.Text = GetTranslation(objectWithTranslations,menuItem.Text);
                    } 
                } 
            } 
        }
    }
}
