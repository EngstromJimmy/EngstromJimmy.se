using System;
using Microsoft.Research.Kinect.Nui;

namespace KinectExtensions
{
    public static class JointExtensions
    {
        public static bool HigherThan(this Joint basejoint, Joint joint)
        {
            return basejoint.Position.Y > joint.Position.Y;
        }

        public static bool LowerThan(this Joint basejoint, Joint joint)
        {
            return basejoint.Position.Y < joint.Position.Y;
        }

        public static bool BetweenVertically(this Joint basejoint, Joint lowerJoint, Joint higherJoint)
        {
            return basejoint.Position.Y > lowerJoint.Position.Y && basejoint.Position.Y < higherJoint.Position.Y;
        }


        public static bool BetweenHorizontally(this Joint basejoint, Joint lowerJoint, Joint higherJoint)
        {
            return basejoint.Position.X > lowerJoint.Position.X && basejoint.Position.X < higherJoint.Position.X;
        }

        public static bool ToTheLeftOf(this Joint basejoint, Joint joint, float amount)
        {
            return basejoint.Position.X < joint.Position.X - amount;
        }

        public static bool ToTheRightOf(this Joint basejoint, Joint joint, float amount)
        {
            return basejoint.Position.X > joint.Position.X + amount;
        }

    }
}
