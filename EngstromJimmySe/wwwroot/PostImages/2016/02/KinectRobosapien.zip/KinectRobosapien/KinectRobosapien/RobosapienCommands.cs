using System;

namespace KinectRobosapien
{
    
    /// <summary>
    /// Static class containing all(?) the remote command fpr a Robosapien v1
    /// The commands are taken from http://isobe.typepad.com/robotics/2005/01/robosapien_usbu.html
    /// The commands are in Uuirt-format
    /// </summary>
    public static class RobosapienCommands
    {
        //Right Arm
        public static string RightArmUp = "R08008109808520212122212221212122212121808720";
        public static string RightArmDown = "R08008101808321212122212121212180862022212121";
        public static string RightArmOut = "R08008109808321212122212121212122218086202121";
        public static string RightArmIn = "R2D9980FE80852021212221212123218086202021808720";
        public static string RightArmAllUp = "R14D18109808520212122212221212122212121808720";
        public static string RightArmAllDown = "R12D08101808321212122212121212180862022212121";
        public static string RightArmAllOut = "R0FD38109808321212122212121212122218086202121";
        public static string RightArmAllIn = "R105180FE80852021212221212123218086202021808720";

        //LeftArm
        public static string LeftArmUp = "R0800810E80832121212221212180852120212221808520";
        public static string LeftArmDown = "R080080F780852021212221212180872080862022212121";
        public static string LeftRightArmOut = "R0800810B80842021212221212180872021218085212121";
        public static string LeftRightArmIn = "R080080F48086202121222122218086208086202221808620";
        public static string LeftArmAllUp = "R1116810E80832121212221212180852120212221808520";
        public static string LeftArmAllDown = "R128980F780852021212221212180872080862022212121";
        public static string LeftArmAllOut = "R0FE6810B80862021212221212180872021218085212121";
        public static string LeftArmAllIn = "R0DC680F48085202121222122218086208086202221808620";

        //Attitude
        public static string WakeUp = "R080080FF8085202121808620808620212122212221808520";
        public static string High5 = "R080080F980852080852120212221212180862022212121";
        public static string Burp = "R080080FE80852080852021212221212122218085212121";
        public static string Fart = "R0800810A808520808520212122212121808620808620808520";
        public static string Roar = "R080080F7808520808520212122218086208086208086202121";
        public static string TalkBack = "R080080EF8085208085202221222180862080862022212121";
        public static string Whistle = "R080081058085208087202121212180872021218085202221";
        public static string Sleep = "R080081008083212121808620202123212021808620808720";
        public static string Bulldozer = "R080080F18085208085212021222121218086208086202121";

        //Arm Combos
        public static string RightSweep = "R0800810380852080852120212221212122212121808720";
        public static string LeftSweep = "R080081028085208087202121212180852120212221808520";
        public static string RightThump = "R0800810180852022218086202021212122212221808520";
        public static string LeftThump = "R080081058085202121808620222180862021212221808620";
        public static string RightPickUp = "R080080F680852021218086202221212180862022212121";
        public static string LeftPickUp = "R080081098085202121808620222180852080862022212121";
        public static string RightThrow = "R0800810180852021218086202221212122218085202221";
        public static string LeftThrow = "R080081008084202221808520202180862021218084202221";
        public static string RightStrike1 = "R080080F78085208087202221212121218086202221808620";
        public static string LeftStrike1 = "R080080EE808520808520222122218086208086202221808620";
        public static string RightStrike2 = "R080080FE8085208087202121212121212221808620808521";
        public static string LeftStrike2 = "R080080F4808620808720222121218087202221808520808720";
        public static string LeftStrike3 = "R080080F980852080852021212221808520212122212121";
        public static string RightStrike3 = "R08008103808520808520212122212121222121212121";

        //Movement
        public static string WalkForward = "R239B80F980842121212221212121218086208086202121";
        public static string WalkBackward = "R153480EF8085202121222121212321808620808421808520";
        public static string StepForward = "R080080F38085202121808620222121218086208086202121";
        public static string StepBackward = "R08008108808520212180862022212121808620808620808520";
        public static string Stop = "R165580FC8085202121222122218085208086208086202121";
        public static string LeanLeft = "R149C80FC8085202121222122218085202121808620808520";
        public static string LeanRight = "R10AD810680852021212221212123212021808620808720";
        public static string TurnStepLeft = "R080080FD80852022218086202021808720212121212121";
        public static string TurnStepRight = "R08008103808420212180862121212121222122212121";
        public static string Left = "R2AAB8104808520212122212221808620212122212121";
        public static string Right = "R1FC381098085202121222122212121222121212121";
        public static string LeanForward = "R080080F0808520212180862022218086208086202221808620";
        public static string LeanBack = "R080080F38085202221808620202121218086212121808521";

        //Program Modes
        public static string RSensor = "R159E810080852022212021808620212122218086202121";
        public static string LSensor = "R15F180FE8085202121222180852121212221808520808620";
        public static string SonicSensor = "R1749810680852021212221808521212180862020212321";
        public static string MainProgram = "R18E28103808520212122218086202121222121212321";
        public static string ExecuteMain = "R1A51810780852022212021808620212122212221808520";


        //Misc
        public static string Demo2 = "R080080F3808520808520212180862021212221808620808520";
        public static string Demo1 = "R080080F58083218085202121808620212122218085212121";
        public static string ListenMode = "R080080F7808520212180862022218085202121808720808520";
        public static string TurnOff = "R080080FD8085208085202121808620212122212121808720";
        public static string Dance = "R080081028085208085202121808620212180862022212121";
    }
}
